/**
 * AEGIS — AI Disaster Management Command Center
 * script.js — Complete Application Logic
 *
 * Features:
 *  - Leaflet map with OSM, search, click coords, popups
 *  - Nominatim geocoding
 *  - GIS risk analysis with safe zone detection
 *  - Evacuation route polyline
 *  - Chart.js dashboards
 *  - Alert system (toast, cards, table)
 *  - AI chatbot with typed responses
 *  - Animated counters, live timestamps
 */

'use strict';

/* =========================================================
   GLOBAL STATE
   ========================================================= */
const APP = {
  map: null,
  markers: { search: null, safeZone: null, alerts: [], heatCircles: [] },
  layers: { heatmap: true, safezones: true, alerts: true },
  evacRoute: null,
  safeZoneLayer: null,
  alertMarkersLayer: null,
  charts: {},
  alertCount: 3,
  currentAnalysis: null,
  chatOpen: false,
};

/* =========================================================
   DATA — Nepal/South Asia Districts & Safe Zones
   ========================================================= */

const SAFE_ZONES = [
  { name: "Tribhuvan University Campus",     lat: 27.6848, lng: 85.3188, capacity: 5000 },
  { name: "Kathmandu Airport Relief Camp",   lat: 27.6988, lng: 85.3592, capacity: 3000 },
  { name: "Bhaktapur Durbar Open Ground",    lat: 27.6722, lng: 85.4270, capacity: 2000 },
  { name: "Pokhara Airport Emergency Zone",  lat: 28.2001, lng: 83.9818, capacity: 4000 },
  { name: "Biratnagar Relief Centre",        lat: 26.4525, lng: 87.2718, capacity: 6000 },
  { name: "Chitwan National Camp",           lat: 27.5291, lng: 84.3542, capacity: 5500 },
  { name: "Butwal Relief Ground",            lat: 27.7005, lng: 83.4488, capacity: 3200 },
  { name: "Dharan Army Camp",                lat: 26.8118, lng: 87.2842, capacity: 4800 },
  { name: "Nepalgunj Field Hospital",        lat: 28.0499, lng: 81.6198, capacity: 2800 },
  { name: "Lukla Emergency Station",         lat: 27.6887, lng: 86.7335, capacity: 800  },
];

const ALERT_DATA = [
  { id: 1, type: "flood",     level: "critical", title: "Flash Flood Warning",    district: "Sindhupalchok", location: "Melamchi Valley",   lat: 27.8358, lng: 85.5640, desc: "River Melamchi overflowing. Immediate evacuation required for riverside communities.", time: Date.now() - 1200000 },
  { id: 2, type: "landslide", level: "high",     title: "Landslide Alert",        district: "Gorkha",        location: "Tsum Valley",        lat: 28.5355, lng: 84.6769, desc: "Saturated slopes with active movement detected. Road closures in effect on BP Highway.", time: Date.now() - 3600000 },
  { id: 3, type: "earthquake",level: "moderate", title: "Seismic Activity",       district: "Dolakha",       location: "Charikot",           lat: 27.6607, lng: 86.0496, desc: "M3.8 tremor recorded. Aftershocks possible. Building inspections underway.", time: Date.now() - 7200000 },
  { id: 4, type: "flood",     level: "high",     title: "River Level Critical",   district: "Chitwan",       location: "Narayanghat",        lat: 27.7039, lng: 84.4062, desc: "Narayani River at 98% capacity. Alert Level 3 issued for downstream areas.", time: Date.now() - 10800000 },
  { id: 5, type: "landslide", level: "moderate", title: "Road Blockage",          district: "Lamjung",       location: "Besisahar",          lat: 28.2301, lng: 84.3758, desc: "Multiple debris flows reported on Marsyangdi Corridor. Rerouting traffic via Dumre.", time: Date.now() - 14400000 },
  { id: 6, type: "drought",   level: "low",      title: "Dry Spell Advisory",     district: "Mustang",       location: "Lo Manthang",        lat: 29.1795, lng: 83.9631, desc: "Extended dry period with <10mm rainfall in 30 days. Agriculture impact assessment ongoing.", time: Date.now() - 86400000 },
];

const TABLE_DATA = [
  { location: "Melamchi Valley", district: "Sindhupalchok", type: "Flood",      risk: "Critical", magnitude: "Stage 4", ts: "2025-07-12 14:32", status: "active" },
  { location: "Tsum Valley",     district: "Gorkha",        type: "Landslide",  risk: "High",     magnitude: "1200m³",  ts: "2025-07-12 12:10", status: "active" },
  { location: "Charikot",        district: "Dolakha",       type: "Earthquake", risk: "Moderate", magnitude: "M3.8",    ts: "2025-07-12 09:47", status: "monitoring" },
  { location: "Narayanghat",     district: "Chitwan",       type: "Flood",      risk: "High",     magnitude: "Stage 3", ts: "2025-07-11 23:15", status: "active" },
  { location: "Besisahar",       district: "Lamjung",       type: "Landslide",  risk: "Moderate", magnitude: "600m³",   ts: "2025-07-11 18:30", status: "monitoring" },
  { location: "Lo Manthang",     district: "Mustang",       type: "Drought",    risk: "Low",      magnitude: "SPI -1.2",ts: "2025-07-10 08:00", status: "resolved" },
];

const DISTRICT_RISK = [
  { name: "Sindhupalchok", score: 94, color: "#ff2d55" },
  { name: "Dolakha",       score: 82, color: "#ff6b35" },
  { name: "Chitwan",       score: 78, color: "#ff6b35" },
  { name: "Gorkha",        score: 73, color: "#ff9f0a" },
  { name: "Lamjung",       score: 65, color: "#ff9f0a" },
  { name: "Makwanpur",     score: 58, color: "#ff9f0a" },
  { name: "Rasuwa",        score: 52, color: "#00c8ff" },
  { name: "Mustang",       score: 38, color: "#30d158" },
];

const RISK_FACTORS_BY_TYPE = {
  flood:      ["Water Level", "Rainfall Rate", "Soil Saturation", "Slope Gradient", "Drainage Capacity"],
  landslide:  ["Slope Stability", "Soil Moisture", "Rainfall Intensity", "Geology Type", "Vegetation Cover"],
  earthquake: ["Seismic Zone", "Soil Liquefaction", "Fault Proximity", "Building Codes", "Historical Activity"],
  drought:    ["Precipitation Deficit", "Temperature Anomaly", "Reservoir Level", "Crop Water Stress", "Groundwater"],
  avalanche:  ["Snow Depth", "Wind Loading", "Temperature Gradient", "Slope Angle", "Recent Snowfall"],
  fire:       ["Fuel Moisture", "Wind Speed", "Temperature", "Humidity", "Terrain Slope"],
};

const CHAT_RESPONSES = {
  "flood": [
    "🌊 **Flood Preparedness**\n\nDuring a flood:\n• Move immediately to higher ground\n• Do NOT walk through flowing water (6 inches can knock you down)\n• Disconnect electrical appliances\n• Keep emergency kit ready: documents, medicines, food for 3 days\n\n**Nepal Emergency**: Call 1148 (NDRRMA) or 100 (Police)",
  ],
  "landslide": [
    "⛰️ **Landslide Safety**\n\nWarning signs to watch for:\n• Unusual cracks in walls or ground\n• Tilting trees or utility poles\n• Sudden changes in water stream clarity\n• Rumbling sounds from hillsides\n\n**If threatened**: Evacuate immediately via the nearest safe route. Do not shelter in basements.",
  ],
  "earthquake": [
    "🌋 **Earthquake Response**\n\nDuring shaking — DROP, COVER, HOLD ON:\n• Get under a sturdy table or desk\n• Cover your head and neck with arms\n• Stay away from windows and exterior walls\n• If outside, move to open area away from buildings\n\n**After**: Expect aftershocks. Check for gas leaks. Do not use elevators.",
  ],
  "shelter": [
    "🏕️ **Nearest Safe Zones (Kathmandu Valley)**\n\n1. Tribhuvan University Campus — 5,000 capacity\n2. Kathmandu Airport Relief Camp — 3,000 capacity\n3. Bhaktapur Durbar Open Ground — 2,000 capacity\n\nUse the Risk Map section to find the nearest safe zone to your current location with evacuation routing.",
  ],
  "prepare": [
    "📦 **Emergency Preparedness Kit**\n\n**72-Hour Kit Essentials:**\n• 3 liters of water per person per day\n• Non-perishable food (dried, canned)\n• First aid kit & prescription medications\n• Copies of ID, insurance, bank documents\n• Flashlight, extra batteries, whistle\n• Warm clothing and sturdy shoes\n• Phone charger (solar/hand-crank)\n• Cash in small denominations",
  ],
  "default": [
    "I'm AEGIS AI, your disaster management assistant. I can help with:\n\n• **Flood** preparedness and response\n• **Landslide** early warning signs\n• **Earthquake** safety protocols\n• **Shelter** and evacuation locations\n• **Emergency kit** checklists\n\nAsk me anything about disaster preparedness in Nepal and South Asia!",
    "Based on current monitoring data, Sindhupalchok and Chitwan districts are at elevated risk due to recent monsoon rainfall. The NDRRMA has issued Level 3 alerts for riverside communities. Use our Risk Map to view your location's specific risk profile.",
  ]
};

/* =========================================================
   INITIALIZATION
   ========================================================= */

document.addEventListener('DOMContentLoaded', () => {
  initNavigation();
  initMap();
  initCharts();
  populateAlertsTable();
  populateAlertsGrid();
  populateReports();
  initCounters();
  initTimestamps();
  showToast('info', 'System Online', 'AEGIS Command Center initialized. All sensors nominal.', 4000);
  setTimeout(() => showToast('warning', 'Weather Alert', 'Heavy rainfall forecast for Bagmati Province next 48 hours.', 5000), 2000);
  setTimeout(() => showToast('danger', 'High Risk', 'Flood risk escalated to CRITICAL in Sindhupalchok District.', 6000), 4500);
});

/* =========================================================
   NAVIGATION
   ========================================================= */

function initNavigation() {
  const links = document.querySelectorAll('.nav-link[data-section]');
  links.forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      const sec = link.dataset.section;
      switchSection(sec);
      links.forEach(l => l.classList.remove('active'));
      link.classList.add('active');
    });
  });

  // Nav search bar -> map section
  document.getElementById('navSearchBtn').addEventListener('click', () => {
    const q = document.getElementById('navSearch').value.trim();
    if (q) {
      document.getElementById('searchInput').value = q;
      switchSection('map');
      document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
      document.querySelector('.nav-link[data-section="map"]').classList.add('active');
      searchLocation();
    }
  });

  document.getElementById('navSearch').addEventListener('keypress', e => {
    if (e.key === 'Enter') document.getElementById('navSearchBtn').click();
  });

  // Update last update time
  updateTimestamp();
  setInterval(updateTimestamp, 60000);
}

function switchSection(id) {
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  const target = document.getElementById(id);
  if (target) { target.classList.add('active'); window.scrollTo({ top: 0, behavior: 'smooth' }); }
  // Trigger map resize when switching to map
  if (id === 'map' && APP.map) setTimeout(() => APP.map.invalidateSize(), 200);
}

function updateTimestamp() {
  const now = new Date();
  const opts = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
  const str = now.toLocaleDateString('en-NP', opts);
  document.getElementById('lastUpdate').textContent = `Last updated: ${str}`;
  document.getElementById('footerSync').textContent = str;
  document.getElementById('reportDate').textContent = str;
}

/* =========================================================
   EMERGENCY BANNER
   ========================================================= */

function closeBanner() {
  const banner = document.getElementById('emergencyBanner');
  banner.classList.add('hidden');
  // Adjust nav position
  document.querySelector('.navbar').style.top = '0';
  document.querySelector('.main-content').style.paddingTop = `calc(var(--nav-h) + 28px)`;
}

/* =========================================================
   ANIMATED COUNTERS
   ========================================================= */

function initCounters() {
  const counters = document.querySelectorAll('.counter');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });
  counters.forEach(c => observer.observe(c));
}

function animateCounter(el) {
  const target = parseInt(el.dataset.target, 10);
  const duration = 1500;
  const step = target / (duration / 16);
  let current = 0;
  const timer = setInterval(() => {
    current = Math.min(current + step, target);
    el.textContent = Math.floor(current);
    if (current >= target) clearInterval(timer);
  }, 16);
}

/* =========================================================
   LEAFLET MAP
   ========================================================= */

function initMap() {
  // Create map centered on Nepal
  APP.map = L.map('leafletMap', {
    center: [28.3949, 84.1240],
    zoom: 7,
    zoomControl: true,
  });

  // OpenStreetMap tile layer
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© <a href="https://openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    maxZoom: 19,
  }).addTo(APP.map);

  // Fullscreen control
  if (L.control.fullscreen) {
    L.control.fullscreen({ position: 'topleft' }).addTo(APP.map);
  }

  // Coordinate display on click
  APP.map.on('click', e => {
    const { lat, lng } = e.latlng;
    document.getElementById('coordDisplay').innerHTML =
      `<i class="fa-solid fa-location-crosshairs"></i> ${lat.toFixed(5)}°N, ${lng.toFixed(5)}°E`;
  });

  // Add default alert markers and safe zone markers
  addAlertMarkers();
  addSafeZoneMarkers();
  addRiskHeatmap();
}

/** Custom colored icon */
function makeIcon(color, faClass) {
  return L.divIcon({
    html: `<div style="
      background:${color};
      width:32px;height:32px;border-radius:50% 50% 50% 0;
      transform:rotate(-45deg);
      border:2px solid rgba(255,255,255,0.4);
      box-shadow:0 2px 12px ${color}80;
      display:flex;align-items:center;justify-content:center;">
      <i class='${faClass}' style='transform:rotate(45deg);color:white;font-size:12px;'></i>
    </div>`,
    className: '',
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -34],
  });
}

function addAlertMarkers() {
  APP.markers.alerts = [];
  const colors = { critical: '#ff2d55', high: '#ff6b35', moderate: '#ff9f0a', low: '#30d158' };
  const icons  = { flood: 'fa-solid fa-house-flood-water', landslide: 'fa-solid fa-hill-rockslide', earthquake: 'fa-solid fa-circle-radiation', drought: 'fa-solid fa-sun', avalanche: 'fa-solid fa-snowflake', fire: 'fa-solid fa-fire' };

  ALERT_DATA.forEach(alert => {
    const marker = L.marker([alert.lat, alert.lng], {
      icon: makeIcon(colors[alert.level] || '#ff9f0a', icons[alert.type] || 'fa-solid fa-triangle-exclamation'),
    }).addTo(APP.map);

    marker.bindPopup(`
      <div style="font-family:'Rajdhani',sans-serif;min-width:200px;">
        <div style="font-weight:700;font-size:1rem;margin-bottom:4px;">${alert.title}</div>
        <div style="color:#aac;font-size:0.8rem;margin-bottom:8px;"><i class="fa-solid fa-location-dot"></i> ${alert.location}, ${alert.district}</div>
        <div style="background:rgba(255,255,255,0.05);padding:8px;border-radius:6px;font-size:0.82rem;line-height:1.5;color:#cde;">${alert.desc}</div>
        <div style="margin-top:8px;font-size:0.72rem;color:#789;">Risk Level: <span style="color:${colors[alert.level]};font-weight:700;">${alert.level.toUpperCase()}</span></div>
      </div>
    `);
    APP.markers.alerts.push(marker);
  });
}

function addSafeZoneMarkers() {
  APP.safeZoneLayer = L.layerGroup();
  SAFE_ZONES.forEach(zone => {
    const marker = L.marker([zone.lat, zone.lng], {
      icon: makeIcon('#30d158', 'fa-solid fa-shield-heart'),
    });
    marker.bindPopup(`
      <div style="font-family:'Rajdhani',sans-serif;min-width:180px;">
        <div style="color:#30d158;font-size:0.72rem;font-weight:700;letter-spacing:1px;margin-bottom:4px;">✓ SAFE ZONE</div>
        <div style="font-weight:700;font-size:0.95rem;margin-bottom:4px;">${zone.name}</div>
        <div style="font-size:0.8rem;color:#aac;">Capacity: ${zone.capacity.toLocaleString()} persons</div>
        <div style="font-size:0.72rem;color:#789;margin-top:4px;">${zone.lat.toFixed(4)}°N, ${zone.lng.toFixed(4)}°E</div>
      </div>
    `);
    APP.safeZoneLayer.addLayer(marker);
  });
  APP.safeZoneLayer.addTo(APP.map);
}

function addRiskHeatmap() {
  // Semi-transparent risk circles for high-risk zones
  const riskAreas = [
    { lat: 27.8358, lng: 85.5640, radius: 15000, color: '#ff2d55', opacity: 0.12 },
    { lat: 28.5355, lng: 84.6769, radius: 12000, color: '#ff6b35', opacity: 0.10 },
    { lat: 27.7039, lng: 84.4062, radius: 14000, color: '#ff9f0a', opacity: 0.10 },
    { lat: 27.6607, lng: 86.0496, radius: 10000, color: '#ff6b35', opacity: 0.09 },
  ];
  APP.markers.heatCircles = riskAreas.map(area =>
    L.circle([area.lat, area.lng], { radius: area.radius, color: area.color, fillColor: area.color, fillOpacity: area.opacity, weight: 1, opacity: 0.4 }).addTo(APP.map)
  );
}

function toggleLayer(layer, visible) {
  if (layer === 'heatmap') {
    APP.markers.heatCircles.forEach(c => visible ? c.addTo(APP.map) : APP.map.removeLayer(c));
  } else if (layer === 'safezones') {
    visible ? APP.safeZoneLayer.addTo(APP.map) : APP.map.removeLayer(APP.safeZoneLayer);
  } else if (layer === 'alerts') {
    APP.markers.alerts.forEach(m => visible ? m.addTo(APP.map) : APP.map.removeLayer(m));
  }
}

/* =========================================================
   GEOCODING & RISK ANALYSIS
   ========================================================= */

async function searchLocation() {
  const query = document.getElementById('searchInput').value.trim() ||
                document.getElementById('navSearch').value.trim();
  if (!query) { showToast('warning', 'Input Required', 'Please enter a location to search.'); return; }

  const btn = document.getElementById('searchBtn');
  btn.innerHTML = '<div class="spinner" style="width:14px;height:14px;border-width:2px;"></div>';
  btn.disabled = true;

  try {
    const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query + ', Nepal')}&format=json&limit=1&addressdetails=1`;
    const res = await fetch(url, { headers: { 'Accept-Language': 'en' } });
    const data = await res.json();

    if (!data.length) {
      showToast('warning', 'Not Found', `Location "${query}" not found. Try adding "Nepal" or a district name.`);
      return;
    }

    const place = data[0];
    const lat = parseFloat(place.lat);
    const lng = parseFloat(place.lon);
    const displayName = place.display_name.split(',').slice(0, 3).join(',');

    // Pan and zoom
    APP.map.setView([lat, lng], 13, { animate: true, duration: 1.2 });

    // Remove old search marker
    if (APP.markers.search) APP.map.removeLayer(APP.markers.search);

    APP.markers.search = L.marker([lat, lng], {
      icon: makeIcon('#00c8ff', 'fa-solid fa-location-dot'),
    }).addTo(APP.map);

    APP.markers.search.bindPopup(`
      <div style="font-family:'Rajdhani',sans-serif;">
        <div style="font-weight:700;font-size:0.95rem;margin-bottom:2px;">${displayName}</div>
        <div style="font-size:0.75rem;color:#789;">${lat.toFixed(5)}°N, ${lng.toFixed(5)}°E</div>
      </div>
    `).openPopup();

    document.getElementById('coordDisplay').innerHTML =
      `<i class="fa-solid fa-location-crosshairs"></i> ${lat.toFixed(5)}°N, ${lng.toFixed(5)}°E`;

    APP.currentAnalysis = { lat, lng, name: displayName };
    showToast('success', 'Location Found', `Zoomed to: ${displayName.split(',')[0]}`);

  } catch (err) {
    showToast('danger', 'Search Failed', 'Could not reach geocoding service. Check your internet connection.');
    console.error('Geocoding error:', err);
  } finally {
    btn.innerHTML = '<i class="fa-solid fa-magnifying-glass"></i>';
    btn.disabled = false;
  }
}

function analyzeRisk() {
  const type = document.getElementById('disasterType').value;
  const resultsDiv = document.getElementById('riskResults');
  const loadingDiv = document.getElementById('resultsLoading');
  const contentDiv = document.getElementById('resultsContent');

  resultsDiv.style.display = 'block';
  loadingDiv.style.display = 'flex';
  contentDiv.style.display = 'none';

  // Simulate API delay
  setTimeout(() => {
    loadingDiv.style.display = 'none';
    contentDiv.style.display = 'block';
    renderRiskResults(type);
  }, 1800);
}

function renderRiskResults(type) {
  // Generate plausible Nepal risk scores
  const baseScores = { flood: 78, landslide: 71, earthquake: 52, drought: 34, avalanche: 45, fire: 28 };
  const variance = Math.floor(Math.random() * 18) - 9;
  const score = Math.min(100, Math.max(5, (baseScores[type] || 50) + variance));

  let level, color;
  if (score >= 80)      { level = 'CRITICAL'; color = '#ff2d55'; }
  else if (score >= 60) { level = 'HIGH';     color = '#ff6b35'; }
  else if (score >= 40) { level = 'MODERATE'; color = '#ff9f0a'; }
  else                  { level = 'LOW';      color = '#30d158'; }

  // Gauge
  const gaugeFill = document.getElementById('gaugeFill');
  const gaugeValue = document.getElementById('gaugeValue');
  const degrees = (score / 100) * 360;
  document.getElementById('riskGauge').style.background =
    `conic-gradient(${color} ${degrees}deg, rgba(255,255,255,0.08) ${degrees}deg)`;
  gaugeValue.textContent = score + '%';

  // Badge
  const badge = document.getElementById('riskBadge');
  badge.textContent = level;
  badge.className = `risk-badge risk-pill ${level.toLowerCase()}`;
  badge.style.background = color + '22';
  badge.style.color = color;
  badge.style.border = `1px solid ${color}44`;

  // Location
  const locName = APP.currentAnalysis ? APP.currentAnalysis.name.split(',')[0] : 'Selected Area';
  document.getElementById('riskLocation').textContent = locName;

  // Risk factors
  const factors = RISK_FACTORS_BY_TYPE[type] || RISK_FACTORS_BY_TYPE.flood;
  const factorsDiv = document.getElementById('riskFactors');
  factorsDiv.innerHTML = factors.map(f => {
    const val = Math.floor(Math.random() * 60 + score - 20).clamp(5, 100);
    let fc = val >= 80 ? '#ff2d55' : val >= 60 ? '#ff6b35' : val >= 40 ? '#ff9f0a' : '#30d158';
    return `
      <div class="risk-factor">
        <span class="risk-factor-label">${f}</span>
        <div class="risk-factor-bar"><div class="risk-factor-fill" style="width:${val}%;background:${fc};"></div></div>
        <span class="risk-factor-val">${val}%</span>
      </div>`;
  }).join('');

  // Find nearest safe zone
  const src = APP.currentAnalysis || { lat: 27.7172, lng: 85.3240 };
  const nearest = findNearestSafeZone(src.lat, src.lng);
  APP.currentSafeZone = nearest;

  document.getElementById('safeZoneInfo').style.display = 'block';
  document.getElementById('safeZoneName').textContent = nearest.zone.name;
  document.getElementById('safeZoneDist').textContent =
    `${nearest.dist.toFixed(1)} km away — Capacity: ${nearest.zone.capacity.toLocaleString()} persons`;
}

/** Find nearest safe zone using Haversine */
function findNearestSafeZone(lat, lng) {
  let best = null, bestDist = Infinity;
  SAFE_ZONES.forEach(zone => {
    const d = haversine(lat, lng, zone.lat, zone.lng);
    if (d < bestDist) { bestDist = d; best = zone; }
  });
  return { zone: best, dist: bestDist };
}

/** Haversine distance in km */
function haversine(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a = Math.sin(dLat/2)**2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
function toRad(d) { return d * Math.PI / 180; }

Number.prototype.clamp = function(min, max) { return Math.min(max, Math.max(min, this)); };

function showEvacRoute() {
  const src = APP.currentAnalysis || { lat: 27.7172, lng: 85.3240 };
  const dst = APP.currentSafeZone;
  if (!dst) return;

  // Remove existing route
  if (APP.evacRoute) APP.map.removeLayer(APP.evacRoute);
  if (APP.markers.safeZone) APP.map.removeLayer(APP.markers.safeZone);

  // Draw polyline (direct route with midpoint offset for visual interest)
  const midLat = (src.lat + dst.zone.lat) / 2 + (Math.random() * 0.04 - 0.02);
  const midLng = (src.lng + dst.zone.lng) / 2 + (Math.random() * 0.04 - 0.02);

  APP.evacRoute = L.polyline(
    [[src.lat, src.lng], [midLat, midLng], [dst.zone.lat, dst.zone.lng]],
    { color: '#30d158', weight: 4, opacity: 0.9, dashArray: '10,6', lineJoin: 'round' }
  ).addTo(APP.map);

  // Safe zone destination marker (pulsing)
  APP.markers.safeZone = L.marker([dst.zone.lat, dst.zone.lng], {
    icon: makeIcon('#30d158', 'fa-solid fa-shield-heart'),
  }).addTo(APP.map).bindPopup(`
    <div style="font-family:'Rajdhani',sans-serif;">
      <div style="color:#30d158;font-weight:700;">EVACUATION DESTINATION</div>
      <div style="font-size:0.95rem;margin-top:4px;">${dst.zone.name}</div>
      <div style="font-size:0.8rem;color:#aac;margin-top:2px;">Distance: ${dst.dist.toFixed(1)} km</div>
    </div>
  `).openPopup();

  // Fit bounds
  APP.map.fitBounds([[src.lat, src.lng], [dst.zone.lat, dst.zone.lng]], { padding: [50, 50] });

  showToast('success', 'Evacuation Route Set',
    `Route to ${dst.zone.name} — ${dst.dist.toFixed(1)} km. Follow green dashed line.`);
}

/* =========================================================
   CHARTS
   ========================================================= */

const CHART_DEFAULTS = {
  responsive: true,
  maintainAspectRatio: true,
  plugins: { legend: { display: false } },
};

Chart.defaults.color = 'rgba(200,220,255,0.6)';
Chart.defaults.borderColor = 'rgba(0,200,255,0.08)';
Chart.defaults.font.family = "'Rajdhani', sans-serif";

function initCharts() {
  initTrendsChart();
  initRiskChart();
  initBarChart();
  initAreaChart();
}

function initTrendsChart() {
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const ctx = document.getElementById('trendsChart').getContext('2d');

  APP.charts.trends = new Chart(ctx, {
    type: 'line',
    data: {
      labels: months,
      datasets: [
        {
          label: 'Flood',
          data: [2,1,3,8,14,22,31,28,19,11,4,2],
          borderColor: '#0066ff',
          backgroundColor: 'rgba(0,102,255,0.1)',
          tension: 0.4, fill: true, pointRadius: 3, pointHoverRadius: 6,
          borderWidth: 2,
        },
        {
          label: 'Landslide',
          data: [1,0,2,5,10,18,25,22,14,7,2,1],
          borderColor: '#ff6b35',
          backgroundColor: 'rgba(255,107,53,0.08)',
          tension: 0.4, fill: true, pointRadius: 3, pointHoverRadius: 6,
          borderWidth: 2,
        },
        {
          label: 'Earthquake',
          data: [3,2,4,3,2,4,5,3,4,2,3,2],
          borderColor: '#bf5af2',
          backgroundColor: 'rgba(191,90,242,0.06)',
          tension: 0.4, fill: true, pointRadius: 3, pointHoverRadius: 6,
          borderWidth: 2,
        },
      ],
    },
    options: {
      ...CHART_DEFAULTS,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: 'rgba(8,18,38,0.95)',
          borderColor: 'rgba(0,200,255,0.2)',
          borderWidth: 1,
          titleFont: { family: "'Orbitron'" },
          bodyFont: { family: "'Rajdhani'", size: 13 },
          padding: 12,
        }
      },
      scales: {
        x: { grid: { color: 'rgba(0,200,255,0.05)' }, ticks: { font: { size: 11 } } },
        y: { grid: { color: 'rgba(0,200,255,0.05)' }, ticks: { font: { size: 11 } }, beginAtZero: true },
      },
    },
  });
}

function initRiskChart() {
  const ctx = document.getElementById('riskChart').getContext('2d');
  APP.charts.risk = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Flood', 'Landslide', 'Earthquake', 'Drought', 'Other'],
      datasets: [{
        data: [38, 29, 18, 10, 5],
        backgroundColor: ['rgba(0,102,255,0.8)', 'rgba(255,107,53,0.8)', 'rgba(191,90,242,0.8)', 'rgba(255,159,10,0.8)', 'rgba(0,200,255,0.4)'],
        borderColor: ['#0066ff', '#ff6b35', '#bf5af2', '#ff9f0a', '#00c8ff'],
        borderWidth: 2, hoverOffset: 8,
      }],
    },
    options: {
      ...CHART_DEFAULTS,
      cutout: '70%',
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: 'rgba(8,18,38,0.95)',
          borderColor: 'rgba(0,200,255,0.2)',
          borderWidth: 1,
          callbacks: { label: ctx => ` ${ctx.label}: ${ctx.raw}%` }
        }
      }
    },
  });
}

function initBarChart() {
  const ctx = document.getElementById('barChart').getContext('2d');
  APP.charts.bar = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['2019','2020','2021','2022','2023','2024'],
      datasets: [
        { label: 'Flood Events',      data: [142,167,189,205,231,188], backgroundColor: 'rgba(0,102,255,0.7)', borderRadius: 6 },
        { label: 'Landslide Events',  data: [98,115,134,156,178,142],  backgroundColor: 'rgba(255,107,53,0.7)', borderRadius: 6 },
        { label: 'Deaths',            data: [312,428,387,510,462,340],  backgroundColor: 'rgba(255,45,85,0.5)',  borderRadius: 6 },
      ],
    },
    options: {
      ...CHART_DEFAULTS,
      plugins: {
        legend: { display: true, labels: { color: 'rgba(200,220,255,0.7)', font: { size: 11, family: "'Rajdhani'" }, padding: 16, boxWidth: 12 } },
        tooltip: { backgroundColor: 'rgba(8,18,38,0.95)', borderColor: 'rgba(0,200,255,0.2)', borderWidth: 1 }
      },
      scales: {
        x: { grid: { display: false }, stacked: false },
        y: { grid: { color: 'rgba(0,200,255,0.05)' }, beginAtZero: true },
      },
    },
  });
}

function initAreaChart() {
  const ctx = document.getElementById('areaChart').getContext('2d');
  APP.charts.area = new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
      datasets: [{
        label: 'Affected Population',
        data: [4200,2100,3800,8900,15600,28400,52000,48000,32000,18000,7400,3200],
        borderColor: '#00c8ff',
        backgroundColor: 'rgba(0,200,255,0.08)',
        tension: 0.4, fill: true, pointRadius: 4,
        borderWidth: 2,
      }],
    },
    options: {
      ...CHART_DEFAULTS,
      plugins: {
        legend: { display: false },
        tooltip: { backgroundColor: 'rgba(8,18,38,0.95)', borderColor: 'rgba(0,200,255,0.2)', borderWidth: 1 }
      },
      scales: {
        x: { grid: { color: 'rgba(0,200,255,0.05)' } },
        y: { grid: { color: 'rgba(0,200,255,0.05)' }, beginAtZero: true,
             ticks: { callback: v => v >= 1000 ? (v/1000).toFixed(0)+'k' : v } },
      },
    },
  });
}

/* =========================================================
   ALERTS TABLE
   ========================================================= */

function populateAlertsTable() {
  const tbody = document.getElementById('alertsTableBody');
  tbody.innerHTML = TABLE_DATA.map(row => `
    <tr>
      <td>${row.location}</td>
      <td>${row.district}</td>
      <td>${getTypeIcon(row.type)} ${row.type}</td>
      <td><span class="risk-pill ${row.risk.toLowerCase()}">${row.risk}</span></td>
      <td style="font-family:var(--font-mono);font-size:0.8rem;">${row.magnitude}</td>
      <td style="font-family:var(--font-mono);font-size:0.78rem;color:var(--text-secondary);">${row.ts}</td>
      <td><span class="status-pill ${row.status}">${capitalize(row.status)}</span></td>
    </tr>
  `).join('');
}

/* =========================================================
   ALERTS GRID
   ========================================================= */

function populateAlertsGrid() {
  const grid = document.getElementById('alertsGrid');
  grid.innerHTML = ALERT_DATA.map(alert => createAlertCard(alert)).join('');
  document.getElementById('alertBadge').textContent =
    ALERT_DATA.filter(a => a.level === 'critical' || a.level === 'high').length;
}

function createAlertCard(alert) {
  const colors = { critical: '#ff2d55', high: '#ff6b35', moderate: '#ff9f0a', low: '#30d158' };
  const icons  = { flood: 'fa-house-flood-water', landslide: 'fa-hill-rockslide', earthquake: 'fa-circle-radiation', drought: 'fa-sun', avalanche: 'fa-snowflake', fire: 'fa-fire' };
  const color = colors[alert.level] || '#ff9f0a';
  const icon = icons[alert.type] || 'fa-triangle-exclamation';
  const timeAgo = getTimeAgo(alert.time);

  return `
    <div class="alert-card ${alert.level}" id="alertCard${alert.id}">
      <div class="alert-card-header">
        <div style="display:flex;gap:10px;align-items:flex-start;">
          <div class="alert-type-icon" style="background:${color}22;color:${color}">
            <i class="fa-solid ${icon}"></i>
          </div>
          <div>
            <div class="alert-title">${alert.title}</div>
            <div class="alert-location"><i class="fa-solid fa-location-dot" style="font-size:0.7rem;color:${color}"></i> ${alert.location}, ${alert.district}</div>
          </div>
        </div>
        <div class="alert-actions">
          <button class="alert-dismiss" onclick="dismissAlert(${alert.id})" title="Dismiss"><i class="fa-solid fa-xmark"></i></button>
        </div>
      </div>
      <div class="alert-meta">
        <span><i class="fa-solid fa-signal"></i> ${capitalize(alert.level)} Risk</span>
        <span><i class="fa-solid fa-tag"></i> ${capitalize(alert.type)}</span>
      </div>
      <div class="alert-desc">${alert.desc}</div>
      <div class="alert-footer">
        <span class="alert-time"><i class="fa-regular fa-clock"></i> ${timeAgo}</span>
        <button class="btn btn-sm btn-outline" onclick="viewOnMap(${alert.lat}, ${alert.lng})">
          <i class="fa-solid fa-map-location-dot"></i> View
        </button>
      </div>
    </div>
  `;
}

function dismissAlert(id) {
  const card = document.getElementById(`alertCard${id}`);
  if (card) { card.style.opacity = '0'; card.style.transform = 'scale(0.9)'; setTimeout(() => card.remove(), 300); }
  APP.alertCount = Math.max(0, APP.alertCount - 1);
  document.getElementById('alertBadge').textContent = APP.alertCount;
}

function generateAlert() {
  const types = ['flood','landslide','earthquake','fire','avalanche'];
  const levels = ['critical','high','moderate','low'];
  const locations = [
    { loc: 'Koshi Corridor', dist: 'Sunsari', lat: 26.6012, lng: 87.1539 },
    { loc: 'Annapurna Base', dist: 'Kaski',   lat: 28.5383, lng: 83.8786 },
    { loc: 'Seti River Basin',dist: 'Kailali', lat: 28.6234, lng: 81.6099 },
    { loc: 'Karnali Highway', dist: 'Jumla',   lat: 29.2748, lng: 82.1840 },
  ];
  const type = types[Math.floor(Math.random() * types.length)];
  const level = levels[Math.floor(Math.random() * levels.length)];
  const place = locations[Math.floor(Math.random() * locations.length)];
  const id = Date.now();

  const newAlert = {
    id, type, level,
    title: `${capitalize(type)} ${capitalize(level)} Alert`,
    district: place.dist, location: place.loc,
    lat: place.lat, lng: place.lng,
    desc: `Automated sensor detected ${type} risk escalation in ${place.loc}. Field assessment teams deployed.`,
    time: Date.now(),
  };

  ALERT_DATA.unshift(newAlert);
  APP.alertCount++;
  document.getElementById('alertBadge').textContent = APP.alertCount;

  const grid = document.getElementById('alertsGrid');
  const div = document.createElement('div');
  div.innerHTML = createAlertCard(newAlert);
  grid.insertBefore(div.firstElementChild, grid.firstChild);

  showToast('danger', `New ${capitalize(level)} Alert`, `${capitalize(type)} risk in ${place.loc}, ${place.dist}`);
}

function clearAllAlerts() {
  document.getElementById('alertsGrid').innerHTML =
    `<div class="glass-card" style="grid-column:1/-1;text-align:center;padding:40px;color:var(--text-secondary);">
      <i class="fa-solid fa-check-circle" style="font-size:2rem;color:var(--accent-green);display:block;margin-bottom:12px;"></i>
      All alerts cleared. System monitoring continues.
    </div>`;
  APP.alertCount = 0;
  document.getElementById('alertBadge').textContent = '0';
  showToast('success', 'Alerts Cleared', 'All alerts dismissed. Monitoring continues.');
}

function viewOnMap(lat, lng) {
  switchSection('map');
  document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
  document.querySelector('.nav-link[data-section="map"]').classList.add('active');
  setTimeout(() => { APP.map.setView([lat, lng], 13, { animate: true }); }, 250);
}

/* =========================================================
   REPORTS
   ========================================================= */

function populateReports() {
  // Situation Report
  document.getElementById('reportBody').innerHTML = `
    <p><strong>Situation Overview:</strong> Nepal is experiencing the peak of the 2025 monsoon season with significantly above-average rainfall across the Bagmati, Gandaki, and Koshi river basins.</p>
    <p><strong>Flood Status:</strong> 14 rivers are currently in warning or danger levels. The Melamchi and Narayani rivers have exceeded danger level. <span style="color:#ff2d55;">3 districts are under Red Alert.</span></p>
    <p><strong>Landslides:</strong> 47 landslide incidents reported in the past 7 days across 18 districts. Sindhupalchok, Gorkha, and Lamjung account for 61% of incidents.</p>
    <p><strong>Casualties:</strong> 23 fatalities and 48 injuries recorded this week. 8,400 families displaced. 156 infrastructure assets damaged.</p>
    <p><strong>Response:</strong> NDRRMA has deployed 14 response teams. 6 field hospitals activated. Air evacuation missions ongoing in Dolakha and Rasuwa.</p>
    <p><strong>Forecast:</strong> Heavy to very heavy rainfall expected for next 72 hours. Risk levels forecast to remain HIGH or above through end of month.</p>
  `;

  // District Rankings
  const list = document.getElementById('rankingList');
  list.innerHTML = DISTRICT_RISK.map((d, i) => `
    <div class="ranking-item">
      <span class="rank-num">#${i + 1}</span>
      <span class="rank-name">${d.name}</span>
      <div class="rank-bar"><div class="rank-bar-fill" style="width:${d.score}%;background:${d.color};"></div></div>
      <span class="risk-pill" style="background:${d.color}22;color:${d.color};border:1px solid ${d.color}44;font-size:0.7rem;padding:2px 8px;">${d.score}</span>
    </div>
  `).join('');
}

/* =========================================================
   TOAST NOTIFICATIONS
   ========================================================= */

const TOAST_ICONS = {
  danger: 'fa-triangle-exclamation',
  warning: 'fa-circle-exclamation',
  success: 'fa-circle-check',
  info: 'fa-circle-info',
};

function showToast(type, title, message, duration = 5000) {
  const container = document.getElementById('toastContainer');
  const id = `toast_${Date.now()}`;
  const icon = TOAST_ICONS[type] || 'fa-circle-info';

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.id = id;
  toast.innerHTML = `
    <i class="fa-solid ${icon} toast-icon"></i>
    <div class="toast-body">
      <div class="toast-title">${title}</div>
      <div class="toast-msg">${message}</div>
    </div>
    <button class="toast-close" onclick="removeToast('${id}')"><i class="fa-solid fa-xmark"></i></button>
  `;
  container.appendChild(toast);

  if (duration > 0) setTimeout(() => removeToast(id), duration);
}

function removeToast(id) {
  const el = document.getElementById(id);
  if (el) { el.classList.add('removing'); setTimeout(() => el.remove(), 300); }
}

/* =========================================================
   DASHBOARD ACTIONS
   ========================================================= */

function refreshDashboard() {
  // Re-animate counters
  document.querySelectorAll('.counter').forEach(c => {
    c.textContent = '0';
    animateCounter(c);
  });
  showToast('success', 'Dashboard Refreshed', 'All sensor data updated from DHM Nepal feeds.');
}

function triggerDrillAlert() {
  const banner = document.getElementById('emergencyBanner');
  const bannerText = document.getElementById('bannerText');
  bannerText.textContent = '🚨 DRILL ALERT: Emergency evacuation drill initiated — This is a test. Please proceed to designated assembly points.';
  banner.style.display = 'flex';
  banner.classList.remove('hidden');
  showToast('danger', 'DRILL ALERT ACTIVATED', 'Emergency evacuation drill initiated. This is a test scenario.');
}

function exportAlerts() {
  const rows = [['Location','District','Type','Risk','Magnitude','Timestamp','Status']];
  TABLE_DATA.forEach(r => rows.push([r.location, r.district, r.type, r.risk, r.magnitude, r.ts, r.status]));
  const csv = rows.map(r => r.map(c => `"${c}"`).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = 'aegis_alerts.csv'; a.click();
  showToast('success', 'Export Complete', 'Alert log exported as aegis_alerts.csv');
}

/* =========================================================
   AI CHATBOT
   ========================================================= */

function toggleChatbot() {
  APP.chatOpen = !APP.chatOpen;
  document.getElementById('chatbotPanel').classList.toggle('open', APP.chatOpen);
  if (APP.chatOpen) {
    document.getElementById('chatNotif').classList.add('hidden');
    document.getElementById('chatInput').focus();
  }
}

function handleChatKey(e) { if (e.key === 'Enter') sendChatMessage(); }

function sendSuggestion(btn) {
  document.getElementById('chatInput').value = btn.textContent;
  sendChatMessage();
}

function sendChatMessage() {
  const input = document.getElementById('chatInput');
  const text = input.value.trim();
  if (!text) return;
  input.value = '';

  appendChatMsg('user', text);

  // Show typing indicator
  const typingId = showTyping();
  setTimeout(() => {
    removeTyping(typingId);
    const response = getChatResponse(text);
    appendChatMsg('bot', response);
  }, 1000 + Math.random() * 800);
}

function appendChatMsg(role, text) {
  const messages = document.getElementById('chatbotMessages');
  const div = document.createElement('div');
  div.className = `chat-msg ${role}`;
  const time = new Date().toLocaleTimeString('en', { hour: '2-digit', minute: '2-digit' });
  div.innerHTML = `
    <div class="msg-avatar"><i class="fa-solid ${role === 'bot' ? 'fa-robot' : 'fa-user'}"></i></div>
    <div class="msg-bubble">
      <p>${text.replace(/\n/g, '<br>').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/•/g, '&bull;')}</p>
      <span class="msg-time">${time}</span>
    </div>
  `;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}

function showTyping() {
  const id = 'typing_' + Date.now();
  const messages = document.getElementById('chatbotMessages');
  const div = document.createElement('div');
  div.className = 'chat-msg bot'; div.id = id;
  div.innerHTML = `
    <div class="msg-avatar"><i class="fa-solid fa-robot"></i></div>
    <div class="msg-bubble">
      <div class="typing-indicator">
        <div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div>
      </div>
    </div>`;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
  return id;
}

function removeTyping(id) {
  const el = document.getElementById(id);
  if (el) el.remove();
}

function getChatResponse(text) {
  const lower = text.toLowerCase();
  if (lower.includes('flood') || lower.includes('water')) return CHAT_RESPONSES.flood[0];
  if (lower.includes('landslide') || lower.includes('slide') || lower.includes('slope')) return CHAT_RESPONSES.landslide[0];
  if (lower.includes('earthquake') || lower.includes('seismic') || lower.includes('tremor')) return CHAT_RESPONSES.earthquake[0];
  if (lower.includes('shelter') || lower.includes('safe zone') || lower.includes('refuge')) return CHAT_RESPONSES.shelter[0];
  if (lower.includes('kit') || lower.includes('prepare') || lower.includes('stock') || lower.includes('supply')) return CHAT_RESPONSES.prepare[0];
  if (lower.includes('risk') || lower.includes('danger') || lower.includes('alert')) {
    return `📊 **Current Risk Summary**\n\nAs of now:\n• **Flood Risk**: CRITICAL (91%) — Sindhupalchok, Chitwan\n• **Landslide Risk**: HIGH (74%) — Gorkha, Lamjung\n• **Earthquake**: STABLE (M2.4 minor activity)\n• **Drought**: LOW risk (38%) — Mustang only\n\nCheck the Risk Map section for your specific area's analysis.`;
  }
  // Default response (random)
  return CHAT_RESPONSES.default[Math.floor(Math.random() * CHAT_RESPONSES.default.length)];
}

/* =========================================================
   UTILITY HELPERS
   ========================================================= */

function getTypeIcon(type) {
  const map = { flood: '🌊', landslide: '⛰️', earthquake: '🌋', drought: '☀️', avalanche: '❄️', fire: '🔥' };
  return map[type.toLowerCase()] || '⚠️';
}

function capitalize(str) { return str ? str.charAt(0).toUpperCase() + str.slice(1) : ''; }

function getTimeAgo(ts) {
  const diff = Date.now() - ts;
  const mins = Math.floor(diff / 60000);
  if (mins < 1)  return 'Just now';
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24)  return `${hrs} hr ago`;
  return `${Math.floor(hrs / 24)} days ago`;
}

function initTimestamps() {
  setInterval(() => {
    // Update any live elements that show relative time
    document.querySelectorAll('.alert-time').forEach((el, i) => {
      if (ALERT_DATA[i]) el.innerHTML = `<i class="fa-regular fa-clock"></i> ${getTimeAgo(ALERT_DATA[i].time)}`;
    });
  }, 30000);
}

/* =========================================================
   SEARCH INPUT — handle enter key in analysis panel
   ========================================================= */
document.addEventListener('DOMContentLoaded', () => {
  const si = document.getElementById('searchInput');
  if (si) si.addEventListener('keypress', e => { if (e.key === 'Enter') searchLocation(); });
});
