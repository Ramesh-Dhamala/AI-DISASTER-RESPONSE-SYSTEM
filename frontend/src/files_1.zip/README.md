# AEGIS — AI Disaster Management Command Center

> A production-quality, hackathon-ready GIS disaster management web application for Nepal and South Asia.

---

## 🚀 Quick Start

```bash
# No build step required — just open in browser
open index.html
```

Or serve locally:
```bash
python3 -m http.server 8000
# Visit http://localhost:8000
```

---

## 📁 Folder Structure

```
disaster-app/
├── index.html          # Main application shell
├── style.css           # Glassmorphism + responsive styles
├── script.js           # Complete application logic
├── assets/
│   └── favicon.ico     # App icon (optional)
└── README.md           # This file
```

---

## ✨ Features

### 🎨 UI/UX
- **Glassmorphism** dashboard with animated gradient background (floating orbs)
- **Orbitron + Rajdhani + JetBrains Mono** font stack for command-center aesthetic
- Fully responsive — works on mobile, tablet, desktop
- Dark mode only, optimized for emergency operations centers

### 🗺️ Interactive GIS Map
- **Leaflet.js + OpenStreetMap** tiles
- **Nominatim geocoding** — search any location in Nepal (live API)
- Click markers with lat/lng display
- Rich popups for each alert and safe zone
- Zoom + **fullscreen controls**
- Toggle layers: Risk Heatmap, Safe Zones, Active Alerts

### 🧠 Advanced GIS Analysis
1. Select disaster type (Flood / Landslide / Earthquake / Drought / Avalanche / Fire)
2. Search a location (geocoded via Nominatim API)
3. Click **Generate Risk Analysis** → realistic sample risk scores + factor breakdown
4. **Haversine algorithm** finds the nearest safe zone from 10 predefined Nepal relief centers
5. Click **Show Evacuation Route** → draws a Leaflet polyline with distance info

### 📊 Dashboard Cards (6 metrics)
- Temperature, Humidity, Landslide, Seismic, Flood Risk, Wind Speed
- **Animated counters** on scroll into view
- Color-coded status badges (Normal / Moderate / High / Critical)
- Top-border risk indicator with critical-pulse animation

### 📈 Charts (Chart.js)
| Chart | Type | Data |
|---|---|---|
| Monthly Disaster Trends | Line (multi-series) | 12-month flood/landslide/earthquake events |
| Risk Distribution | Doughnut | % breakdown by disaster type |
| 2024 Statistics | Grouped Bar | 6-year event + death counts |
| Affected Population | Area Line | Monthly affected persons |

### 🔔 Alert System
- **Emergency banner** (dismissible, drill-trigger capable)
- **Toast notifications** — appear top-right with auto-dismiss
- **Alert cards grid** — each card has type icon, risk badge, description, map-link, dismiss
- **Alert history table** with Location, Type, Risk, Magnitude, Timestamp, Status
- Live alert counter badge in navbar
- **Generate Alert** button creates random new alerts

### 🤖 AI Chatbot
- ChatGPT-style floating panel (bottom-right)
- **Typing animation** before each response
- Contextual responses for: flood, landslide, earthquake, shelter, emergency kit, risk
- Quick-suggestion buttons
- Opens/closes with bubble toggle

### 📋 Reports Section
- Situation Report prose
- District Risk Rankings (bar visualization)
- 6-year disaster statistics (bar chart)
- Affected population trend (area chart)

### 🦺 Footer
- Nepal emergency contacts: NDRRMA 1148, Police 100, Fire 101, Ambulance 102, NRCS
- Data source attribution
- Live sync timestamp

---

## 🛠️ Technology Stack

| Technology | Version | Purpose |
|---|---|---|
| HTML5 | — | Semantic structure |
| CSS3 | — | Glassmorphism, animations, responsive |
| Vanilla JavaScript | ES2022 | All logic, no frameworks |
| Leaflet.js | 1.9.4 | Interactive map |
| Leaflet Fullscreen | 3.0.2 | Map fullscreen control |
| Chart.js | 4.4.0 | All charts |
| OpenStreetMap | — | Map tiles |
| Nominatim API | — | Free geocoding |
| Font Awesome | 6.5.1 | Icons |
| Google Fonts | — | Orbitron, Rajdhani, JetBrains Mono |

**No backend. No build step. No npm. No API keys required.**

---

## 🗂️ Data Sources (Sample/Demo)

- Alert locations: Real Nepal district coordinates (BIPAD Portal reference)
- Safe zones: 10 actual Nepal relief/shelter coordinates
- Risk scores: Generated with realistic Nepal monsoon baselines
- Chart data: Based on DHM Nepal and NDRRMA historical reports
- Geocoding: Live Nominatim/OSM API (internet required for search)

---

## 🔧 Customization

### Add Real Alert Data
Replace `ALERT_DATA` array in `script.js` with live API data from:
- [BIPAD Portal](https://bipadportal.gov.np) — Nepal disaster data
- [DHM Nepal](https://www.dhm.gov.np) — Hydrology/meteorology
- [USGS Earthquake](https://earthquake.usgs.gov/fdsnws/event/1/) — Seismic events

### Add More Safe Zones
Extend the `SAFE_ZONES` array in `script.js`:
```js
{ name: "Your Location", lat: 27.xxx, lng: 85.xxx, capacity: 1000 }
```

### Integrate Real AI
Replace `getChatResponse()` in `script.js` with a real API call:
```js
async function getChatResponse(text) {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {...});
  // ...
}
```

---

## 📱 Browser Support

| Browser | Support |
|---|---|
| Chrome 90+ | ✅ Full |
| Firefox 88+ | ✅ Full |
| Safari 14+ | ✅ Full |
| Edge 90+ | ✅ Full |
| Mobile Chrome/Safari | ✅ Responsive |

---

## 👥 Team & Credits

Built for disaster management hackathon — Nepal focus.

- Map data © OpenStreetMap contributors
- Geocoding: Nominatim / OpenStreetMap
- Icons: Font Awesome 6
- Fonts: Google Fonts

---

## 📄 License

MIT License — Free to use, modify, and distribute.

---

*"Technology in service of saving lives."*
